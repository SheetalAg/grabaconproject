package com.sheetal.grabacon

class SaveData (
   val id:String,
   val mob:Int,
   val password:Int
)