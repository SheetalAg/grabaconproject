package com.sheetal.grabacon

import android.app.Dialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseException
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.database.FirebaseDatabase
import java.util.concurrent.TimeUnit

class LoginActivity : AppCompatActivity() {
    lateinit var mcallbacks: PhoneAuthProvider.OnVerificationStateChangedCallbacks
    lateinit var mAuth:FirebaseAuth
    lateinit var btnLogin: Button
    lateinit var btnLogin2:Button
    lateinit var etMobileNumber: EditText
    lateinit var etVerification: EditText
    lateinit var RegisterYourself: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        btnLogin = findViewById(R.id.btnLogin)
        btnLogin2=findViewById(R.id.btnLogin2)
        etMobileNumber = findViewById(R.id.etMobileNumber)
        etVerification = findViewById(R.id.etVerification)
        RegisterYourself = findViewById(R.id.RegisterYourself)
        mAuth= FirebaseAuth.getInstance()
        btnLogin.setOnClickListener {
            view:View?->verify()
        }
        btnLogin2.setOnClickListener {
            startActivity(Intent(this@LoginActivity,MainActivity::class.java))
        }
            RegisterYourself.setOnClickListener {
                startActivity(Intent(this@LoginActivity, RegistrationActivity::class.java))
            }
        }
    private fun verificationCallbacks(){
        mcallbacks=object:PhoneAuthProvider.OnVerificationStateChangedCallbacks(){
            override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                SignIn(credential)
            }

            override fun onVerificationFailed(p0: FirebaseException) {
                Toast.makeText(this@LoginActivity,"Verification Failed",Toast.LENGTH_SHORT).show()
            }

            override fun onCodeSent(p0: String, p1: PhoneAuthProvider.ForceResendingToken) {
                super.onCodeSent(p0, p1)
            }
        }
    }
    private fun verify(){
        verificationCallbacks()
        val phnNo=etMobileNumber.text.toString()
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phnNo,60,TimeUnit.SECONDS,this,mcallbacks)

    }
    private fun SignIn(credential: PhoneAuthCredential){
        mAuth.signInWithCredential(credential).addOnCompleteListener {
            task:Task<AuthResult>->
            if (task.isSuccessful){
                Toast.makeText(this,"LoggedIn successfully",Toast.LENGTH_SHORT).show()
                startActivity(Intent(this@LoginActivity,MainActivity::class.java))
            }
        }
    }
    }
