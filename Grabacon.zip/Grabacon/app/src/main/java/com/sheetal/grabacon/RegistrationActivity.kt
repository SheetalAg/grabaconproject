package com.sheetal.grabacon

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.database.FirebaseDatabase
import de.hdodenhof.circleimageview.CircleImageView
import java.util.jar.Manifest

class RegistrationActivity : AppCompatActivity() {
    lateinit var etrName: EditText
    lateinit var etrEmail:EditText
    lateinit var profile_image:CircleImageView
    lateinit var profile_update:CircleImageView
    
    lateinit var btnRegister: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)
        etrName = findViewById(R.id.etrName)
        etrEmail = findViewById(R.id.etrEmail)
        profile_image = findViewById(R.id.profile_image)
        profile_update = findViewById(R.id.profile_update)
        btnRegister = findViewById(R.id.btnRegister)
        btnRegister.setOnClickListener {
            saveData()
        }

        profile_update.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_DENIED)
                {
                    val permission= arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE);
                    requestPermissions(permission, PERMISSION_CODE);
                } else {
                    PickImageFromGallery();
                }
            } else {
                PickImageFromGallery();
            }
        }
    }
    private fun PickImageFromGallery() {
        val intent=Intent(Intent.ACTION_PICK)
        intent.type="image/*"
        startActivityForResult(intent, IMAGE_PICK_CODE)
    }

    companion object{
        private val IMAGE_PICK_CODE=1000;
        private val PERMISSION_CODE=1001;
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when(requestCode){
            PERMISSION_CODE->{
                if (grantResults.size>0&& grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    PickImageFromGallery()
                }
                else{
                    Toast.makeText(this,"Permission Denied",Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(resultCode== Activity.RESULT_OK&&resultCode== IMAGE_PICK_CODE)
        {
            profile_image.setImageURI(data?.data)
        }
    }
        fun saveData(){
            var etrNamedata=etrName.text.toString()
            var etrEmaildata=etrEmail.text.toString()
            var etrProfileImage=profile_image.toString()
            var map= mutableMapOf<String,Any>()
            map["profile"]=etrProfileImage
            map["name"]=etrNamedata
            map["Email"]=etrEmaildata
            FirebaseDatabase.getInstance().reference.child("users")
                .child("1").setValue(map)


    }
}